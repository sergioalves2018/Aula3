import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IChatAula extends Remote{
	
	Message recebeMensagem(Message msg) throws RemoteException;
	
}
