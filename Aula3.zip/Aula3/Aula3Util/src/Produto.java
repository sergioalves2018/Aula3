
public class Produto {
	
	private int quantidade = -1;
	private float valor = -1;
	private String nome = null;
	
	public int getQtd() {
		return quantidade;
	}
	public void setQtd(int quantidade) {
		this.quantidade = quantidade;
	}
	public float getValor() {
		return valor;
	}
	public void setValor(float valor) {
		this.valor = valor;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}	
}
