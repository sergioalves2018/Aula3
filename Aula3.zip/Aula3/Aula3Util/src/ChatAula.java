import java.io.FileWriter;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ChatAula extends UnicastRemoteObject implements IChatAula{
	
	private static final long serialVersionUID = 412321221L;
	
	private Connection conn;
	private Produto produto;

	public ChatAula(Connection conn) throws RemoteException{
		super();
		this.conn = conn;
		this.produto = new Produto();
	}

	@Override
	public Message recebeMensagem(Message msg) throws RemoteException {
		insereMsgBanco(msg);
		insereArquivo(msg);
		
		String resp = defineResposta(msg.getMessage());
		
		Message resposta = new Message("Sistema", resp);
		insereMsgBanco(resposta);
		insereArquivo(resposta);
		
		return resposta;
	}
	
	private String defineResposta(String m) {
		/*
			"o nome � ..."
			"o valor � ..."
			"a quantidade em estoque � ..."
			
			"qual o nome?"
			"qual o valor?"
			"qual o valor de 10 unidades?"
			"qual a quantidade em estoque?"
		 */
		String resp = "N�o entendi direto, se precisar digite 'ajuda'";
    	
    	if(m.indexOf("o nome � ")>-1) {
    		m = m.replace("o nome � ", "").trim();
    		if(!m.isEmpty()) {
    			produto.setNome(m);
    			atualizaNomeProdutoBanco(m);
    			resp = "OK, nome configurado.";
    		}
    	}
    	else if(m.indexOf("o valor � ")>-1) {
    		m = m.replace("o valor � ", "").trim();
    		try {
    			float valor = Float.parseFloat(m.replace(",", "."));
    			produto.setValor(valor);
    			atualizaValorProdutoBanco(valor);
    			resp = "OK, valor configurado.";
    		}catch (Exception e) {}
    	}
    	else if(m.indexOf("a quantidade em estoque � ")>-1) {
    		m = m.replace("a quantidade em estoque � ", "").trim();
    		try {
    			int qtd = Integer.parseInt(m);
    			produto.setQtd(qtd);
    			atualizaQtdProdutoBanco(qtd);
    			resp = "OK, quantidade configurada.";
    		}catch (Exception e) {}
    	}
    	else if(m.indexOf("qual o nome?")>-1) {
    		resp = "O nome do produto � "+produto.getNome();
    	}
    	else if(m.indexOf("qual a quantidade em estoque?")>-1) {
    		resp = "A quantidade em estoque � "+produto.getQtd();
    	}
    	else if(m.indexOf("qual o valor de ")>-1) {
    		m = m.replaceAll("[^\\d]", "");
    		System.out.println(m);
    		try {
    			int qtd = Integer.parseInt(m);
    			resp = "O para a quantidade "+qtd+" � "+qtd*produto.getValor();
    		}catch (Exception e) {}
    	}
    	else if(m.indexOf("qual o valor?")>-1) {
    		resp = "O valor do produto � "+produto.getValor();
    	}
		return resp;
	}
	
	private void insereMsgBanco(Message msg) {
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement("insert into mensagens values (?, ?);");
			ps.setString(1, msg.getUsuario());
			ps.setString(2, msg.getMessage());
			ps.execute();
		} catch (Exception e) {
			System.err.println("Erro ao inserir no banco");
			e.printStackTrace();
		}
	}
	
	private void atualizaNomeProdutoBanco(String nome) {
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement("update produto set nome = ?;");
			ps.setString(1, nome);
			ps.execute();
		} catch (Exception e) {
			System.err.println("Erro ao inserir no banco");
			e.printStackTrace();
		}
	}
	
	private void atualizaValorProdutoBanco(Float valor) {
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement("update produto set valor = ?;");
			ps.setFloat(1, valor);
			ps.execute();
		} catch (Exception e) {
			System.err.println("Erro ao inserir no banco");
			e.printStackTrace();
		}
	}
	
	private void atualizaQtdProdutoBanco(int qtd) {
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement("update produto set quantidade = ?;");
			ps.setInt(1, qtd);
			ps.execute();
		} catch (Exception e) {
			System.err.println("Erro ao inserir no banco");
			e.printStackTrace();
		}
	}
	
	private Produto getProdutoBanco() {
		Produto p = new Produto();
		try {
			Statement st =  conn.createStatement();
			ResultSet rs = st.executeQuery("select * from produto");
			if(rs.next()) {
				p.setNome(rs.getString(0));
				p.setValor(rs.getFloat(1));
				p.setQtd(rs.getInt(2));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return p;		
	}
	
	private void insereArquivo(Message msg) {
		FileWriter fileWriter;
		PrintWriter writer;
		try {
			fileWriter = new FileWriter("mensagens.txt", true);
			writer = new PrintWriter(fileWriter);
			writer.println(msg.getUsuario() + ": \"" + msg.getMessage()+"\"");
			writer.close();
		} catch (Exception e) {
			System.err.println("Erro ao inserir no arquivo");
		}
	}

}
