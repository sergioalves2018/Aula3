import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import javax.swing.*;
import javax.swing.event.*;

public class MyPanel extends JPanel {
	private JButton bt;
    private JTextField msg;
    private JTextArea tela;
    private IChatAula chat;
    private JScrollPane scroll;

    public MyPanel(String nome) throws Exception {
        //construct components
        bt = new JButton ("Enviar");
        msg = new JTextField (5);
        tela = new JTextArea (5, 5);
        scroll = new JScrollPane(tela);

        //set components properties
        tela.setEnabled (false);

        //adjust size and set layout
        setPreferredSize (new Dimension (416, 288));
        setLayout (null);

        //add components
        add (bt);
        add (msg);
        add (scroll);

        //set component bounds (only needed by Absolute Positioning)
        bt.setBounds (315, 250, 85, 25);
        msg.setBounds (15, 250, 290, 25);
        scroll.setBounds (15, 15, 385, 225);
        
        chat = (IChatAula) Naming.lookup("rmi://localhost:8282/chat");
		        
        bt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String texto = msg.getText();
				msg.setText("");
				
				if("ajuda".equals(texto)) {
					ajudar();
				}else {
					Message ida = new Message(nome, texto);
					addMsgTela(ida);
					Message volta;
					try {
						volta = chat.recebeMensagem(ida);
					} catch (RemoteException e1) {
						volta = new Message("Cliente", "Algo deu errado");
					}
					addMsgTela(volta);
				}
			}
		});
    }

    public static void main (String[] args) throws Exception {
    	String nome = JOptionPane.showInputDialog("Digite seu Nome:");
		if(nome == null || nome.equals("")){
			JOptionPane.showMessageDialog(null, "Cancelado", "Chat Info", 0);	
		}else {
			JFrame frame = new JFrame ("Usu�rio: " + nome);
	        frame.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	        frame.getContentPane().add (new MyPanel(nome));
	        frame.pack();
	        frame.setVisible (true);
		}
    }
    
    private void ajudar(){
		String help = "Voc� pode definir:\r\n" + 
				"-o nome do produto:\r\n\"o nome � ...\"\r\n" + 
				"-o valor do produto:\r\n\"o valor � ...\"\r\n" + 
				"-a quantidade em estoque:\r\n\"a quantidade em estoque � ...\"\r\n" + 
				"\r\nVoc� pode perguntar:\r\n" + 
				"-o nome do produto:\r\n\"qual o nome?\"\r\n" + 
				"-o valor do produto:\r\n\"qual o valor?\"\r\n" + 
				"-o valor do produto para varias unidades:\r\n\"qual o valor de 10 unidades?\"\r\n" + 
				"-a quantidade em estoque:\r\n\"qual a quantidade em estoque?\"";
		JOptionPane.showMessageDialog(null, help, "Ajuda", 1);
	}
    
    private void addMsgTela(Message m) {
    	tela.setText(tela.getText()+"\n"+m);
    }
}